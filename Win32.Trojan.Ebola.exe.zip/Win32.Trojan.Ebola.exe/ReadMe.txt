Very malicious so dont run this lmao
